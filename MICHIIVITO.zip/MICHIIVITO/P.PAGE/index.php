<?php include("includes/header.php"); ?>

  <div class="untree_co-hero overlay" style="background-image: url('images/hero-img-1-min.jpg');">


    <div class="container">
      <div class="row align-items-center justify-content-center">

        <div class="col-12">

          <div class="row justify-content-center ">

            <div class="col-lg-6 text-center ">
              <h1 class="mb-4 heading text-white" data-aos="fade-up" data-aos-delay="100">La Educacion es la clave del liderazgo</h1>
              <p class="mb-0" data-aos="fade-up" data-aos-delay="300"><a href="about.php" class="btn btn-secondary">Leer Mas</a></p>

            </div>


          </div>

        </div>

      </div> <!-- /.row -->
    </div> <!-- /.container -->

  </div> <!-- /.untree_co-hero -->


  <div class="untree_co-section">
    <div class="container">
      <div class="row justify-content-center mb-3">
        <div class="col-lg-7 text-center" data-aos="fade-up" data-aos-delay="0">
          <h2 class="line-bottom text-center mb-4">Nuestras Materias</h2>
        </div>
      </div>
      <div class="row align-items-stretch">
      <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="0">
  <a href="#" class="category d-flex align-items-center justify-content-center h-100">
    <div>
    <i class="uil uil-book"></i>
</div>
    <div>
      <h3>Lengua Española</h3>
    </div>
  </a>
</div>

        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="200">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
              <i class="uil uil-calculator"></i>
            </div>
            <div>
              <h3>Matematicas</h3>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="100">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
            <i class="uil uil-users-alt"></i>
            </div>
            <div>
              <h3>Ciencias Sociales</h3>
            </div>
          </a>
        </div>
        
        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="300">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
              <i class="uil uil-trees"></i>
            </div>
            <div>
              <h3>Ciencias Naturales</h3>
            </div>
          </a>
        </div>


        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="0">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
            <i class="uil uil-globe"></i>
            </div>
            <div>
              <h3>Ingles</h3>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="100">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
            <i class="uil uil-football"></i>
            </div>
            <div>
              <h3>Deportes</h3>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="200">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
              <i class="uil uil-camera"></i>
            </div>
            <div>
              <h3>Artes</h3>
            </div>
          </a>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-3 mb-4" data-aos="fade-up" data-aos-delay="300">
          <a href="#" class="category d-flex align-items-center justify-content-center h-100">
            <div>
              <i class="uil uil-circle-layer"></i>
            </div>
            <div>
              <h3>F.H.I.R</h3>
            </div>
          </a>
        </div>
        

      </div>

      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="400">
        <div class="col-lg-8 text-center">
        </div>
      </div>
    </div>
  </div>

  <div class="services-section">
    <div class="container">
      <div class="row justify-content-between">
        <div class="col-lg-4 mb-5 mb-lg-0">

          <div class="section-title mb-3" data-aos="fade-up" data-aos-delay="0">
            <h2 class="line-bottom mb-4">Hazte parte de nuestra comunidad</h2>
          </div>

          <p data-aos="fade-up" data-aos-delay="100">Si te unes a nuestra comunidad, podrás acceder a una variedad de herramientas y recursos diseñados específicamente para apoyar a los estudiantes de nuestro hermoso país. Nos dedicamos a ofrecerte soluciones que faciliten tu aprendizaje y desarrollo académico, brindándote acceso a materiales educativos, plataformas interactivas, y asesoramiento personalizado.</p>
      
          <ul class="ul-check list-unstyled mb-5 primary" data-aos="fade-up" data-aos-delay="200">
            <li>Blog para compatir informacion o dudas con otros estudiantes</li>
            <li>Interaccion entre estudiantes</li>
            <li>Biblioteca</li>
          </ul>
          <!-- SE PODRIA PONER UN LINK PARA EL LOGIN O EL REGISTRARSE -->
          <p data-aos="fade-up" data-aos-delay="300"><a href="../FORUM/blog/index.php" class="btn btn-primary">Comienza</a></p>

        </div>
        <div class="col-lg-6" data-aos="fade-up" data-aos-delay="0">
          <figure class="img-wrap-2">
            <img src="images/teacher-min.jpg" alt="Image" class="img-fluid">
            <div class="dotted"></div>
          </figure>

        </div>
      </div>
    </div>
  </div>



  

  <div class="untree_co-section pt-0 bg-img overlay" style="background-image: url('images/img-school-1-min.jpg');">
    <div class="container">
      <div class="row align-items-center justify-content-center text-center">
        <div class="col-lg-7">
          <h2 class="text-white mb-3" data-aos="fade-up" data-aos-delay="0">Los Recursos Necesarios para los Estudiantes de Nuestro Pais</h2>
          
        </div>
      </div>
    </div>  
  </div> <!-- /.untree_co-section -->

  <div class="untree_co-section">
    <div class="container">
      <div class="row justify-content-between">
        <div class="col-lg-5 mb-5">
          <h2 class="line-bottom mb-4" data-aos="fade-up" data-aos-delay="0">Nosotros</h2>
          <p data-aos="fade-up" data-aos-delay="100">En MICHIIVITO, somos un equipo apasionado por el aprendizaje y la colaboración. Nuestra misión es crear un espacio digital donde los estudiantes puedan compartir conocimientos, resolver dudas y acceder a recursos educativos que les ayuden a alcanzar sus metas académicas.</p>
  
          <p data-aos="fade-up" data-aos-delay="200">
            <a href="about.php" class="btn btn-outline-primary">Leer Mas</a>
          </p>
        </div>
        <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
          <div class="bg-1"></div>
          <a href="https://vimeo.com/342333493" data-fancybox class="video-wrap">
            <span class="play-wrap"><span class="icon-play"></span></span>
            <img src="images/img-school-4-min.jpg" alt="Image" class="img-fluid rounded">
          </a>
        </div>
      </div>
    </div>
  </div> <!-- /.untree_co-section -->

  

  <!-- .accordion-item -->

          </div>

        </div>
      </div>
    </div>
  </div> <!-- /.untree_co-section -->

  <?php include("includes/footer.php"); ?>
    </body>

  </html>
