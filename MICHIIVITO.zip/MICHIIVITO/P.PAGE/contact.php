<?php include("includes/header.php"); ?>
  
  
<div class="untree_co-hero overlay" style="background-image: url('images/img-school-2-min.jpg');">
    <div class="container">
      <div class="row align-items-center justify-content-center">
        <div class="col-12">
          <div class="row justify-content-center ">
            <div class="col-lg-6 text-center ">
              <h1 class="mb-4 heading text-white" data-aos="fade-up" data-aos-delay="100">Contactanos</h1>
              <div class="mb-5 text-white desc mx-auto" data-aos="fade-up" data-aos-delay="200">
                <p>En MICHIIVITO, estamos aquí para ayudarte. Si deseas hacer alguna consulta, enviarnos tus comentarios o simplemente ponerte en contacto con nosotros, no dudes en escribirnos.  </p>
              </div>

              <p class="mb-0" data-aos="fade-up" data-aos-delay="300"><a href="#" class="btn btn-secondary">Explora Nuestro Foro</a></p>

            </div>


          </div>

        </div>

      </div> <!-- /.row -->
    </div> <!-- /.container -->

  </div> <!-- /.untree_co-hero -->



  <div class="untree_co-section">
  <div class="container">
    <div class="row">
    
      <div class="col-lg-12 mr-auto order-1" data-aos="fade-up" data-aos-delay="200">        
        <form action="#">
          <div class="row">
            <div class="col-6 mb-3">
              <input type="text" class="form-control" placeholder="Nombre">
            </div>
            <div class="col-6 mb-3">
              <input type="email" class="form-control" placeholder="Email">
            </div>
            <div class="col-12 mb-3">
              <input type="text" class="form-control" placeholder="Materia">
            </div>
            <div class="col-12 mb-3">
              <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Mensaje"></textarea>
            </div>

            <div class="col-12">
              <input type="submit" value="Enviar" class="btn btn-primary">
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

      
    </div>
  </div>

  <?php include("includes/footer.php"); ?>
  </body>

  </html>
