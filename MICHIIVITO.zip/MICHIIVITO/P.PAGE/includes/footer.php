
<div class="site-footer">
<div class="container">

  <div class="row">
    <div class="col-lg-3 mr-auto">
      <div class="widget">
        <h3>Acerca de Nosotros<span class="text-primary">.</span> </h3>
        <p>Aqui podran encontrar toda la informacion que desean saber acerca de MICHIIVITO, podran conocer mas afondo por lo que somos</p>
      </div> <!-- /.widget -->
    </div> <!-- /.col-lg-3 -->

    <div class="col-lg-2 ml-auto">
      <div class="widget">
        <h3>Materias</h3>
        <ul class="list-unstyled float-left links">
          <li><a href="#">Matematicas</a></li>
          <li><a href="#">Ciencias Naturales</a></li>
          <li><a href="#">Ciencias Sociales</a></li>
          <li><a href="#">Lengua Española</a></li>
          <li><a href="#">Muchas Mas</a></li>
        </ul>
      </div> <!-- /.widget -->
    </div> <!-- /.col-lg-3 -->

    <div class="col-lg-3">
      <div class="widget">
        <h3>Gallery</h3>
        <ul class="instafeed instagram-gallery list-unstyled">
          <li><a class="instagram-item" href="images/gal_1.jpg" data-fancybox="gal"><img src="images/gal_1.jpg" alt="" width="72" height="72"></a>
          </li>
          <li><a class="instagram-item" href="images/gal_2.jpg" data-fancybox="gal"><img src="images/gal_2.jpg" alt="" width="72" height="72"></a>
          </li>
          <li><a class="instagram-item" href="images/gal_3.jpg" data-fancybox="gal"><img src="images/gal_3.jpg" alt="" width="72" height="72"></a>
          </li>
          <li><a class="instagram-item" href="images/gal_4.jpg" data-fancybox="gal"><img src="images/gal_4.jpg" alt="" width="72" height="72"></a>
          </li>
          <li><a class="instagram-item" href="images/gal_5.jpg" data-fancybox="gal"><img src="images/gal_5.jpg" alt="" width="72" height="72"></a>
          </li>
          <li><a class="instagram-item" href="images/gal_6.jpg" data-fancybox="gal"><img src="images/gal_6.jpg" alt="" width="72" height="72"></a>
          </li>
        </ul>
      </div> <!-- /.widget -->
    </div> <!-- /.col-lg-3 -->


    <div class="col-lg-3">
      <div class="widget">
        <h3>Contact</h3>
        <address>43 Raymouth Rd. Baltemoer, London 3910</address>
        <ul class="list-unstyled links mb-4">
          <li><a href="tel://11234567890">+1(123)-456-7890</a></li>
          <li><a href="tel://11234567890">+1(123)-456-7890</a></li>
          <li><a href="mailto:info@mydomain.com">info@mydomain.com</a></li>
        </ul>
      </div> <!-- /.widget -->
    </div> <!-- /.col-lg-3 -->

  </div> <!-- /.row -->
<div id="overlayer"></div>
<div class="loader">
  <div class="spinner-border" role="status">
    <span class="sr-only">Loading...</span>
  </div>
</div>

<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/jquery.sticky.js"></script>
<script src="js/aos.js"></script>
<script src="js/custom.js"></script>