<section class="mb-5">
    <div class="card bg-light">
        <div class="card-body">
            <?php
            if (!isset($_SESSION['id'])):
            ?>
                Para comentar debes <a href="login.php">Acceder</a>
            <?php else: ?>
                <?php
                $id_user = $_SESSION['id'];
                $sql = "SELECT id, usuario FROM login WHERE id = '$id_user'";
                $resultado = $base->prepare($sql);
                $resultado->execute();
                ?>
                <form class="mb-4" action="procesa_comentarios.php" method="post">
                    <input type="hidden" name="id_post" value="<?php echo $id_post ?>">
                    <?php foreach ($resultado as $datos): ?>
                        <input type="hidden" name="id_usuario" value="<?php echo $datos['id'] ?>">
                        <input type="hidden" name="usuario" value="<?php echo $datos['usuario'] ?>">
                    <?php endforeach; ?>
                    <textarea class="form-control" rows="3" placeholder="Únete a la conversación y deja un comentario!" name="comentario"></textarea>
                    <button class="btn btn-info mt-2" type="submit" name="enviar">Comentar</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</section>

<h3 class="mb-2">Comentarios</h3>
<hr>
<section class="mb-5">

    <?php
    // Modificación de la consulta SQL para ordenar los comentarios por ID en orden descendente (del más grande al más pequeño)
    $sql = "SELECT * FROM comentarios WHERE id_post = '$id_post' ORDER BY id DESC";
    $resultado = $base->prepare($sql);
    $resultado->execute();
    $registros = $resultado->rowCount();

    if ($registros < 1) {
        echo "No hay comentarios en este post";
    } else { 
    ?>
        <?php foreach ($resultado as $datos): ?>
            <div class="comentario-container mb-3">
                <div class="fw-bold"><?php echo $datos['usuario']; ?> | <?php echo $datos['fecha']; ?></div>
                <p><?php echo $datos['comentario']; ?></p>       
            </div>
            <!-- Línea separadora más corta -->
            <hr style="border: 1px solid rgba(0, 0, 0, 0.1); margin: 10px 0 10px 0; width: 40%;">
        <?php endforeach; ?>
    <?php } ?>

</section>
