<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Crear Post - Blog</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Enlace a la hoja de estilos de Bootstrap (CDN) en la sección <head> -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Crear Post</h3>
                                </div>
                                <div class="card-body">

                                    <?php
                                    include('config/conexion.php');
                                    $id_user = $_GET['id'];
                                    $sql = "SELECT usuario FROM login WHERE id = '$id_user'";
                                    $resultado = $base->prepare($sql);
                                    $resultado->execute();
                                    ?>
                                    <form action="procesa_crear_post.php" method="post" enctype="multipart/form-data" autocomplete="off">
                                        <input type="hidden" name="id_usuario" value="<?php echo htmlspecialchars($id_user); ?>"><br>

                                        <?php foreach ($resultado as $datos): ?>
                                            <input type="hidden" name="usuario" value="<?php echo htmlspecialchars($datos['usuario']); ?>"><br>
                                        <?php endforeach; ?>

                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" type="text" placeholder="Titulo" name="titulo" required  />
                                                    <label for="titulo">Titulo</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" type="text" placeholder="Categoria" name="categoria" required />
                                                    <label for="categoria">Categoria</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="imagen">Imagen</label>
                                            <input class="form-control" type="file" name="imagen" id="imagen" accept="image/*" required />
                                        </div>

                                        <div class="form-floating mb-3">
                                            <textarea class="form-control h-25" rows="5" placeholder="Post" name="post" required></textarea>
                                            <label for="post">Post</label>
                                        </div>

                                        <div class="mt-4 mb-0">
                                            <div class="d-grid">
                                                <button class="btn btn-primary" type="submit" name="enviar">Crear Post</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>