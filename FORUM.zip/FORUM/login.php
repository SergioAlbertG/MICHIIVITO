<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
            font-family: Arial, sans-serif;
        }
        h1 {
            color: #495057;
            font-weight: 300;
        }
        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 50px auto;
        }
        .form-group input {
            border-radius: 4px;
            padding: 10px;
            border: 1px solid #ccc;
            width: 100%;
        }
        .form-group input:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        button {
            background-color: blueviolet;
            color: white;
            border: none;
            width: 100%;
            padding: 10px;
            border-radius: 4px;
        }
        button:hover {
            background-color: darkviolet;
        }
        .links a {
            color: #007bff;
        }
        .links a:hover {
            text-decoration: underline;
        }
        .message {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="login-container">
            <h1 class="text-center">Bienvenido</h1>
            <form action="procesa_login.php" method="post" autocomplete="off">
                <div class="form-group">
                    <label for="user">Usuario</label>
                    <input type="text" class="form-control" id="user" name="user" required>
                </div>
                <div class="form-group">
                    <label for="pass">Password</label>
                    <input type="password" class="form-control" id="pass" name="pass" required>
                </div>
                <button type="submit" name="enviar">Acceder</button>
            </form>
            <div class="links">
                <p class="text-center">¿No tienes cuenta aún? <a href="registro_user.php">Registrarte</a></p>
                <p class="text-center"><a href="formulario_restablecer.php">¿Olvidaste tu Password?</a></p>
            </div>

            <!-- Mensajes de error o éxito -->
            <div class="message">
                <?php if (isset($_GET['mensaje'])): ?>
                    <div class="alert alert-warning" role="alert">
                        <?php echo htmlentities($_GET['mensaje']); ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['smserror'])): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo htmlentities($_GET['smserror']); ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_GET['exito'])): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo htmlentities($_GET['exito']); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
