<?php 

try{

    $base = new PDO ('mysql:host=localhost; dbname=forum',  'root', '');
    $base ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
}catch(exception $e){
    die('Error al conectar con la base de datos: ' . $e->getMessage());
}

define("LEER_MAS",  "Leer Mas");
?>