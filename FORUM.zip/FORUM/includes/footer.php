<footer class="py-3 bg-primary">
  <div class="container">
    <p class="m-0 text-center text-white">Copyright &copy; MICHIIVITO 2025</p>
  </div>
</footer>
